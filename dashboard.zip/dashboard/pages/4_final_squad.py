# dashboard/pages/4_final_squad.py
# Football Atlas — Final Squad page
#
# The 26 selected players, grouped by position, with a short data-driven
# justification per player built from their strongest sub-scores.
#
# Localized (issue #15) — fully translated, this is the most
# decision-critical page for Coach Ouahbi's staff. All static text goes
# through dashboard/i18n.py's t() helper so it follows the sidebar
# language switcher (EN/FR/AR).

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from dashboard.data_loader import load_latest_top26, available_component_columns
from dashboard.sidebar import render_sidebar, apply_sidebar_filters
from dashboard.i18n import t
from dashboard.notes_store import get_all_notes
from analytics.ml.player_clustering import ARCHETYPE_EMOJI  # NEW 2026-07-29

st.set_page_config(page_title="Football Atlas — Final Squad", page_icon="🏆", layout="wide")
render_sidebar()
st.title(t("nav.final_squad_title"))

top26_full = load_latest_top26()
if top26_full is None:
    st.error(t("final_squad.no_gold_error"))
    st.stop()

top26 = apply_sidebar_filters(top26_full)
if top26.empty:
    st.info(t("final_squad.no_match_filters"))
    st.stop()

component_cols = available_component_columns(top26)

# #20 — Coach/Staff Notes, compact read-only view. Loaded ONCE for all 26
# players (not once per row) since notes_store.get_all_notes() reads the
# whole JSON file — see that module's docstring for why this is decoupled
# from the Bronze/Silver/Gold pipeline entirely (top26/players_scored
# have nothing to do with where notes live).
all_notes = get_all_notes()

if "PlayerDNA" in top26.columns and (top26["PlayerDNA"] != "N/A").any():
    st.caption(t("final_squad.dna_caption"))


def _justification(row) -> str:
    """Picks the player's single strongest sub-score as a one-line justification."""
    if not component_cols:
        return t("final_squad.justification_default", score=f"{row['DSSScore']:.3f}")
    best_col = max(component_cols, key=lambda c: row[c])
    label_map = {
        "PerformanceScore": t("final_squad.label_performance"),
        "FormScore": t("final_squad.label_form"),
        "MentalScore": t("final_squad.label_mental"),
        "AvailabilityScore": t("final_squad.label_availability"),
        "InternationalScore": t("final_squad.label_international"),
        "ChemistryScore": t("final_squad.label_chemistry"),
        "PressureIndex": t("final_squad.label_pressure"),
        "FlexibilityScore": t("final_squad.label_flexibility"),
    }
    return t("final_squad.justification", label=label_map.get(best_col, best_col), score=f"{row[best_col]:.2f}")


POSITION_ORDER = ["GK", "DEF", "MID", "FWD"]
POSITION_LABELS = {
    "GK": t("final_squad.position_gk"),
    "DEF": t("final_squad.position_def"),
    "MID": t("final_squad.position_mid"),
    "FWD": t("final_squad.position_fwd"),
}

for pos in POSITION_ORDER:
    group = top26[top26["position"] == pos].sort_values("DSSScore", ascending=False)
    if group.empty:
        continue
    st.subheader(f"{POSITION_LABELS[pos]} ({len(group)})")
    cols = st.columns(min(len(group), 4))
    for i, (_, row) in enumerate(group.iterrows()):
        with cols[i % len(cols)]:
            st.markdown(f"**#{int(row['Rank'])} {row['player_name']}**")
            st.caption(row.get("club", ""))
            dna = row.get("PlayerDNA")
            if dna and dna != "N/A":
                emoji = ARCHETYPE_EMOJI.get(dna, "🏷️")
                st.markdown(f"{emoji} *{dna}*")
            st.progress(min(max(row["DSSScore"], 0.0), 1.0), text=t("final_squad.dss_progress", score=f"{row['DSSScore']:.3f}"))
            st.caption(_justification(row))

            note = all_notes.get(str(row.get("player_id", "")))
            with st.expander(t("final_squad.note_expander")):
                if note and note.get("text"):
                    st.write(note["text"])
                    st.caption(t("final_squad.note_last_edited", author=note["author"], time=note["updated_at"]))
                else:
                    st.caption(t("final_squad.note_empty"))
    st.divider()

expected_caps = {"GK": 3, "DEF": 9, "MID": 9, "FWD": 5}
actual_counts = top26_full["position"].value_counts().to_dict()
mismatches = [f"{p}: {actual_counts.get(p,0)} (expected {c})" for p, c in expected_caps.items() if actual_counts.get(p,0) != c]
if mismatches:
    st.warning(t("final_squad.mismatch_warning", mismatches="; ".join(mismatches)))
else:
    st.success(t("final_squad.mismatch_success"))